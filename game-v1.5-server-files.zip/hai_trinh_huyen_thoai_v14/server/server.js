const http=require("http"),fs=require("fs"),path=require("path"),crypto=require("crypto");
const PORT=Number(process.env.PORT||8080),ROOT=path.resolve(__dirname,"..","client");
const MIME={".html":"text/html; charset=utf-8",".css":"text/css; charset=utf-8",".js":"text/javascript; charset=utf-8",".json":"application/json; charset=utf-8"};
http.createServer((req,res)=>{const u=new URL(req.url,"http://localhost");
if(u.pathname==="/api/health"){res.writeHead(200,{"Content-Type":"application/json"});return res.end(JSON.stringify({ok:true,game:"Hai Trinh Huyen Thoai",version:"1.3.0"}))}
let name=decodeURIComponent(u.pathname);if(name==="/")name="/index.html";let f=path.resolve(ROOT,"."+name);if(!f.startsWith(ROOT+path.sep)){res.writeHead(403);return res.end("Forbidden")}
fs.readFile(f,(e,b)=>{if(e){res.writeHead(404);return res.end("Không tìm thấy tệp.")}res.writeHead(200,{"Content-Type":MIME[path.extname(f)]||"application/octet-stream","Cache-Control":"no-store"});res.end(b)})}).listen(PORT,"0.0.0.0",()=>console.log(`Game demo đang chạy: http://localhost:${PORT}`));
