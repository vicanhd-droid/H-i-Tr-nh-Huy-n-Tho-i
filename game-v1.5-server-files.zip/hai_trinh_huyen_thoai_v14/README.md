# Hải Trình Huyền Thoại v1.4 — Gear 5 Cinematic

Bản demo RPG 2D fan-made chạy trên trình duyệt điện thoại bằng Node.js/Termux.

## Tính năng v0.9
- Mở rộng roster với hơn 50 nhân vật và nhiều biến thể riêng: Luffy Gear 2, Gear 3, Gear 4 Boundman, Snakeman, Tankman, Gear 5 Nika, Haki Bá Vương; Zoro Ashura/Enma; Sanji Ifrit Jambe; Roger, Oden, Rayleigh, Marco, Râu Đen và nhiều nhân vật khác.
- Mỗi biến thể là một tướng riêng với chỉ số, vai trò, phẩm chất và tuyệt kỹ riêng.
- Tự nhận roster mới khi mở bản cập nhật; cố gắng giữ dữ liệu đã lưu từ v0.8.
- Thẻ tướng với hiệu ứng màu theo phẩm chất.
- Triệu hồi 1 lần, 10 lần hoặc dùng vé miễn phí.
- Tỉ lệ triệu hồi mẫu: SSR 8%, SR 30%, R 62%.
- Đếm mảnh nhân vật hiển thị trên thẻ; lưu trạng thái bằng localStorage.
- Đội hình, chiến đấu, nâng cấp, trang bị và vượt ải từ bản trước.

## Chạy bằng Termux
Giải nén thư mục `hai_trinh_huyen_thoai_v14` vào Download, rồi chạy:

```bash
pkg install nodejs -y
termux-setup-storage
cd /sdcard/Download/hai_trinh_huyen_thoai_v14/server
node server.js
```

Mở Chrome: `http://127.0.0.1:8080`

Đây là demo cục bộ, chưa phải APK hay game online. Các nhân vật có tên thuộc One Piece; dự án không kèm tranh ảnh chính thức.


## Bản v1.4 — tuyệt kỹ Gear 5 Cinematic
- Khi tướng `op_luffy_gear5` tung kỹ năng, game mở cảnh tuyệt kỹ toàn màn hình trước khi tính sát thương.
- Nút **BỎ QUA** hoặc video kết thúc mới cho trận đấu tiếp tục; sát thương được xử lý một lần sau cảnh.
- Không cần video MP4: game tự chạy hoạt ảnh Gear 5 bằng CSS/JavaScript, gồm hào quang, nắm đấm phóng lớn, tia sáng, vòng xung kích và rung màn hình. Đây là hoạt ảnh 2D phong cách anime, không phải mô hình 3D thật.
- Để dùng video của riêng bạn, đặt tệp MP4 tại `client/assets/skills/luffy_gear5.mp4`. Nên dùng video dọc hoặc 16:9, H.264/AAC, ngắn khoảng 5–12 giây; chỉ dùng nội dung bạn có quyền sử dụng.
- Bản demo vẫn chạy cục bộ; chưa có multiplayer trực tuyến.
